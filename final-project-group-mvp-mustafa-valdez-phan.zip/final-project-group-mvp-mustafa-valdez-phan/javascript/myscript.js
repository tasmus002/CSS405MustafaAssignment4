 /* jshint esversion: 6 */
 /*
   Author: Aidan Valdez
    Date: Fall 2025
    File Name: myscript.js
*/
const locations = [ 
  {
    name: "Richfield Store",
    address: "1120 Lakestreet Dr N", 
    hours: "Mon-Thurs: 11 AM - 9 PM", 
    mapEmbed:"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2823.7337517613473!2d-93.156483!3d44.9490802!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87f62a73a0f7d51b%3A0x69af65c2d3a46f2f!2sConcordia%20University%2C%20St.%20Paul!5e0!3m2!1sen!2sus!4v1765498337863!5m2!1sen!2sus"
  },
  {
    name: "Waconia Store",
    address: "3440 Jump Street Dr", 
    hours: "Mon-Thurs: 11 AM - 9 PM", 
    mapEmbed:"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2823.7337517613473!2d-93.156483!3d44.9490802!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87f62a73a0f7d51b%3A0x69af65c2d3a46f2f!2sConcordia%20University%2C%20St.%20Paul!5e0!3m2!1sen!2sus!4v1765498337863!5m2!1sen!2sus"
  },
];

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("locations-container");
  locations.forEach(loc => {
    const section = document.createElement("section");
    section.classList.add("single-location");
    section.innerHTML = `
      <h3>${loc.name}</h3>
      <p>Location: ${loc.address}</p>
      <p>Hours: ${loc.hours}</p>
    `;
    container.appendChild(section);
  });

  // Set the map to the first location by default
  const mapFrame = document.getElementById("map-frame");
  mapFrame.src = locations[0].mapEmbed;
});
